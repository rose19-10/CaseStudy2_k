import React, { useContext, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthContext } from './context/AuthContext';
import ProtectedRoute from './components/ProtectedRoute';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Sidebar from './components/Sidebar';
import { motion } from 'framer-motion';
import './components/style.css';  // ✅ Import the stylesheet
import './components/Home.css';
import './components/Login.css'; 
import './components/Register.css';
import './components/QrPage.css';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import ManageUsers from './pages/ManageUsers';
import Profile from './pages/Profile';
import ActivityLogs from './pages/ActivityLogs';
import Form from './pages/Form';
import Masterlist from './pages/Masterlist';
import Home from './pages/Home'; // Import Home page
import QrPage from './pages/QrPage';
import './components/Sidebar.css'; // ✅ Import Sidebar styles
import ProfilePage from './pages/ProfilePage'; // Make sure the import path is correct
import './components/ProfilePage.css'; // 

function App() {
  const auth = useContext(AuthContext); // ✅ Get AuthContext safely
  const user = auth?.user || null; // ✅ Prevents destructuring error

  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleSidebar = () => {
    setIsCollapsed(!isCollapsed);
  };

  // ✅ Define Animation Variants
const pageVariants = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0, transition: { duration: 0.4, ease: 'easeOut' } },
  exit: { opacity: 0, y: -20, transition: { duration: 0.3, ease: 'easeIn' } }
};

// ✅ Use in Routes
<Route path="/dashboard" element={
  <motion.div variants={pageVariants} initial="initial" animate="animate" exit="exit">
    <Dashboard />
  </motion.div>
} />

  return (
    <>
      <ToastContainer position="top-right" autoClose={3000} />
      <Router>
      <div className="d-flex">
        {/* Sidebar on the left */}
        <Sidebar isCollapsed={isCollapsed} toggleSidebar={toggleSidebar} />
         {/* Main Content - Adjusts automatically */}
         <div className={`main-content ${isCollapsed ? 'collapsed' : ''}`}>
         
        <Routes>
          {/* Show Login & Register pages only when no user is logged in */}
          {!user && (
            <>
              <Route path="/" element={<Home />} /> {/* ✅ Set Home as Landing Page */}
              <Route path="/login" element={<Login />} />
              <Route path="/register" element={<Register />} />
              <Route path="/qr" element={<QrPage />} />
              <Route path="/students/:id" element={<ProfilePage />} />
            </>
          )}

          {/* Protect Routes */}
          {user && (
            <>
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute allowedRoles={['admin', 'user']}>
                    <Dashboard />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/form"
                element={
                  <ProtectedRoute allowedRoles={['admin', 'user']}>
                    <Form />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/qr"
                element={
                  <ProtectedRoute allowedRoles={['admin', 'user']}>
                    <QrPage />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/masterlist"
                element={
                  <ProtectedRoute allowedRoles={['admin', 'user']}>
                    <Masterlist />
                  </ProtectedRoute>
                }
              />
              <Route
                path="/students/:id"
                  element={
                    <ProtectedRoute allowedRoles={['admin', 'user']}>
                      <ProfilePage />
                    </ProtectedRoute>
                  }
              />
              {user.role === 'admin' && (
                <Route
                  path="/manage-users"
                  element={
                    <ProtectedRoute allowedRoles={['admin']}>
                      <ManageUsers />
                    </ProtectedRoute>
                  }
                />
              )}
              <Route
                path="/profile"
                element={
                  <ProtectedRoute allowedRoles={['admin', 'user']}>
                    <Profile />
                  </ProtectedRoute>
                }
              />
              {user.role === 'admin' && (
                <Route
                  path="/logs"
                  element={
                    <ProtectedRoute allowedRoles={['admin']}>
                      <ActivityLogs />
                    </ProtectedRoute>
                  }
                />
              )}
            </>
          )}
        </Routes>
        </div>
      </div>
      </Router>
    </>
  );
}

export default App;
