import React, { useState, useEffect, useContext } from 'react';
import axios from 'axios';
import { AuthContext } from '../context/AuthContext';
import {
  PieChart, Pie, Cell, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid, Legend, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar
} from 'recharts';

const API_URL = 'http://localhost:5000/students';

const Dashboard = () => {
  const auth = useContext(AuthContext);
  const [students, setStudents] = useState([]);

  useEffect(() => {
    fetchStudents();
  }, []);

  const fetchStudents = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(API_URL, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setStudents(response.data);
    } catch (error) {
      console.error('Error fetching students:', error);
    }
  };

  const totalStudents = students.length;
  
  // Color Palette
  const COLORS = [
    '#FF9800', // Orange-Yellow (vibrant and stands out)
    '#FFC107', // Amber (subtle but still very visible)
    '#FFD54F', // Light Amber (softer, but still provides contrast)
    '#FFF9C4', // Very Light Yellow (for subtle accents)
  ];

  // Gender Distribution (Monochromatic Pie Chart)
  const genderData = [
    { name: 'Male', value: students.filter((s) => s.sex === 'Male').length || 0 },
    { name: 'Female', value: students.filter((s) => s.sex === 'Female').length || 0 },
    { name: 'Others', value: students.filter((s) => s.sex === 'Others').length || 0 },
    { name: 'Prefer not to say', value: students.filter((s) => s.sex === 'Prefer not to say').length || 0 },
  ];

    // Years Stayed in Residence
    const yearsStayedData = students.reduce((acc, s) => {
      acc[s.lengthStay] = (acc[s.lengthStay] || 0) + 1;
      return acc;
    }, {});
    const barChartData = Object.entries(yearsStayedData).map(([years, count]) => ({
      years: `${years} years`,
      count,
    }));
  
  // Age Distribution (Colorful Pie Chart with Creative Legend)
  const ageGroups = [
    { range: '0-18', min: 0, max: 18 },
    { range: '19-35', min: 19, max: 35 },
    { range: '36-50', min: 36, max: 50 },
    { range: '51+', min: 51, max: 120 },
  ];
  const ageData = ageGroups.map((group, index) => ({
    name: group.range,
    value: students.filter((s) => s.age >= group.min && s.age <= group.max).length,
    color: COLORS[index % COLORS.length],
  }));

    // ✅ Educational Attainment
  const educationLevels = [
    'No Grade Completed',
    'Elementary Graduate',
    'Highschool Graduate',
    'Technical Vocational Graduate',
    'College Graduate',
    'Masters Graduate',
    'Doctorate Graduate',
  ];

  // Educational Attainment (Spider Chart)
  const educationData = educationLevels.map((level) => ({
    name: level,
    value: students.filter((s) => s.hea === level).length || 0,
  }));

  return (
    <div className="dashboard-container ">
      <h1 className="dashboard-title">Welcome, {auth.user?.username || 'Guest'}</h1>
      
      <div className="grid-container">
        {/* Total Residents Card with Highlighted Number */}
        <div className="grid-item card total-residents">
          <h2>Total Residents</h2>
          <p className="number" style={{ fontSize: '10.5rem', fontWeight: 'bold', color: 'white' }}>{totalStudents}</p>
        </div>
        
         {/* Years Stayed */}
         <div className="grid-item card medium">
          <h3>Years Stayed</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={barChartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="years" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#fff" />
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        {/* Age Distribution with Colorful Pie Chart and Creative Legend */}
        <div className="grid-item card small">
          <h3>Age Distribution</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={ageData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={100}>
                {ageData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip />
              <Legend layout="horizontal" verticalAlign="bottom" align="center" wrapperStyle={{ fontSize: '12px' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* Educational Attainment (Spider Chart) */}
        <div className="grid-item card wide">
          <h3>Educational Attainment</h3>
          <ResponsiveContainer width="100%" height={300}>
            <RadarChart cx="50%" cy="50%" outerRadius="80%" data={educationData}>
              <PolarGrid />
              <PolarAngleAxis dataKey="name" />
              <PolarRadiusAxis />
              <Radar name="Education" dataKey="value" stroke="#ffff" fill="#ffff" fillOpacity={0.6} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
        {/* Gender Distribution */}
        <div className="grid-item card large">
          <h3>Gender Distribution</h3>
          <ResponsiveContainer width="85%" height={300}>
            <PieChart>
              <Pie 
                data={genderData} 
                dataKey="value" 
                nameKey="name" 
                cx="50%"  // Moves the pie chart slightly left for better spacing
                cy="50%" 
                outerRadius={100}
              >
                {genderData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
              <Legend 
                layout="vertical" 
                align="right" 
                verticalAlign="middle"
                iconSize={15} // Adjust icon size for better visibility
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
