import React from 'react';
import QrGenerator from '../components/QrGenerator';
import QrScanner from '../components/QrScanner';

export default function QrPage() {
  return (
    <div className="qr-page-container">
      <div className="qr-section">
        <QrGenerator />
      </div>
      <div className="qr-section">
        <QrScanner />
      </div>
    </div>
  );
}