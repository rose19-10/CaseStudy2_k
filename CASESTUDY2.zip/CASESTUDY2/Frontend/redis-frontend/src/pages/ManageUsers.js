import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import AuthContext from '../context/AuthContext';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const ManageUsers = () => {
  const { user } = useContext(AuthContext);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/auth/users', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setUsers(response.data);
      setLoading(false);
    } catch (error) {
      toast.error('Error fetching users');
      setLoading(false);
    }
  };

  const updateUserRole = async (username, newRole) => {
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `http://localhost:5000/auth/users/${username}`,
        { role: newRole },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success(`Updated ${username} to ${newRole}`);
      setTimeout(() => fetchUsers(), 300);
    } catch (error) {
      toast.error('Error updating user role');
    }
  };

  const deleteUser = async (username) => {
    if (!window.confirm(`Are you sure you want to delete ${username}?`)) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/auth/users/${username}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      toast.success(`Deleted ${username}`);
      fetchUsers();
    } catch (error) {
      toast.error('Error deleting user');
    }
  };

  if (!user || user.role !== 'admin') {
    return <h2 className="text-center text-danger">🚫 Access Denied</h2>;
  }

  return (
    <div className="container mt-5">
      <h2 className="text-center">Manage Users</h2>

      {/* ✅ Show spinner while loading users */}
      {loading && (
        <div className="text-center my-3">
          <div className="spinner-border text-primary" role="status"></div>
        </div>
      )}

      <div className="table-responsive">
        <table className="table table-hover user-table">
          <thead className="table-light">
            <tr>
              <th>Username</th>
              <th>Role</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((usr) => (
              <tr key={usr.username}>
                <td>{usr.username}</td>
                <td>
                  <select
                    className="form-select"
                    value={usr.role}
                    onChange={(e) => updateUserRole(usr.username, e.target.value)}
                  >
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                  </select>
                </td>
                <td>
                  <button className="btn btn-danger btn-sm" onClick={() => deleteUser(usr.username)}>
                    <i className="bi bi-trash"></i> Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ManageUsers;
