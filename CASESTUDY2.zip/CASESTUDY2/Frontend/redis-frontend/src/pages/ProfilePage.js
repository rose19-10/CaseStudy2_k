import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';

const ProfilePage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchStudent = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get(`http://localhost:5000/students/${id}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setStudent(response.data);
      } catch (error) {
        toast.error('Failed to load student data');
        navigate('/masterlist');
      } finally {
        setLoading(false);
      }
    };

    fetchStudent();
  }, [id, navigate]);

  if (loading) {
    return <div className="text-center mt-5">Loading...</div>;
  }

  if (!student) {
    return <div className="text-center mt-5">Student not found</div>;
  }

  return (
    <div className="container mt-4">
      <div className="card profile-card">
        <div className="card-header bg-primary text-white">
          <h2>Student Profile</h2>
        </div>
        <div className="card-body">
          <div className="row">
            <div className="col-md-4 text-center">
              <div className="profile-image-placeholder">
                <i className="bi bi-person-circle" style={{ fontSize: '8rem' }}></i>
              </div>
              <h3 className="mt-3">{student.firstName} {student.lastName}</h3>
              <p className="text-muted">ID: {student.id}</p>
            </div>
            <div className="col-md-8">
              <div className="row">
                <div className="col-md-6">
                  <h4>Personal Information</h4>
                  <p><strong>Date of Birth:</strong> {student.dob}</p>
                  <p><strong>Age:</strong> {student.age}</p>
                  <p><strong>Gender:</strong> {student.sex}</p>
                  <p><strong>Civil Status:</strong> {student.cStatus}</p>
                </div>
                <div className="col-md-6">
                  <h4>Contact Information</h4>
                  <p><strong>Email:</strong> {student.email}</p>
                  <p><strong>Phone:</strong> {student.cNumber}</p>
                  <p><strong>Present Address:</strong> {student.presentAddress}</p>
                  <p><strong>Provincial Address:</strong> {student.provincialAddress}</p>
                </div>
              </div>
              <div className="row mt-4">
                <div className="col-12">
                  <h4>Education & Background</h4>
                  <p><strong>Highest Education:</strong> {student.hea}</p>
                  <p><strong>Religion:</strong> {student.religion}</p>
                  <p><strong>Years in Residence:</strong> {student.lengthStay}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="card-footer text-end">
          <button 
            className="btn btn-secondary"
            onClick={() => navigate('/masterlist')}
          >
            Back to List
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfilePage;