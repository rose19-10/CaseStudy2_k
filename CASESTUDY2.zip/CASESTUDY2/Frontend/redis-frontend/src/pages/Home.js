import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';


const Home = () => {
  return (
    <div className="home-container">
      <motion.div 
        className="hero-section"
        initial={{ opacity: 0, y: -50 }} 
        animate={{ opacity: 1, y: 0 }} 
        transition={{ duration: 1 }}
      >
        <h1>Welcome to <span className="highlight">Barangay Ditucalan Information System</span></h1>
        <Link to="/login" className="btn-explore">Explore Now</Link>
      </motion.div>

      
    </div>
  );
};

export default Home;
