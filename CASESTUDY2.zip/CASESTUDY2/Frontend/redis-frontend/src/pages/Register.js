import React, { useState } from 'react';
import { motion } from 'framer-motion'; // ✅ Animation Library
import axios from 'axios';
import { useNavigate } from 'react-router-dom';


const Register = () => {
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    role: 'user'
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      console.log('Submitting registration:', JSON.stringify(formData));

      const response = await axios.post('http://localhost:5000/auth/register', formData, {
        headers: { 'Content-Type': 'application/json' }
      });

      console.log('Response:', response.data);

      setTimeout(() => {
        setLoading(false);
        alert('Registration successful! You can now log in.');
        navigate('/login');
      }, 2000);
    } catch (err) {
      console.error('Registration error:', err.response?.data);
      setLoading(false);
      setError(err.response?.data?.errors[0]?.msg || 'Registration failed');
    }
  };

  return (
    <div className="register-page">
      {/* Animated Background */}
      <motion.div
        className="animated-bg"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 2 }}
      ></motion.div>

      {/* Register Form */}
      <motion.div
        className="register-container"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, type: 'spring', stiffness: 120 }}
      >
        <div className="register-card">
          <h2 className="register-title">Create an Account</h2>
          <p className="register-subtitle">Sign up to get started</p>

          {error && <div className="alert alert-danger">{error}</div>}

          <form onSubmit={handleSubmit} className="register-form">
            <div className="form-group">
              <input
                type="text"
                name="username"
                className="form-control"
                placeholder="Username"
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <input
                type="password"
                name="password"
                className="form-control"
                placeholder="Password"
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <select name="role" className="form-control" onChange={handleChange} required>
              <option value="">Select a role</option>
                <option value="user">Employee</option>
                <option value="admin">Admin</option>
              </select>
            </div>

            <button type="submit" className="btn register-btn" disabled={loading}>
              {loading ? (
                <>
                  <span className="spinner-border spinner-border-sm"></span> Registering...
                </>
              ) : (
                'Register'
              )}
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

export default Register;
