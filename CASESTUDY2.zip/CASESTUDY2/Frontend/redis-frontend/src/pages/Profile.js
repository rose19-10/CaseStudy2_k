import React, { useState, useContext } from 'react';
import axios from 'axios';
import AuthContext from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Profile = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    username: user?.username || '',
    newPassword: '',
  });

  const [loading, setLoading] = useState(false); // ✅ For spinner

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const token = localStorage.getItem('token');
      await axios.put(
        'http://localhost:5000/auth/profile',
        formData,
        { headers: { Authorization: `Bearer ${token}` } }
      );
      toast.success('Password updated successfully! 🎉 Please re-login.');

      setTimeout(() => {
        setLoading(false);
        localStorage.removeItem('token');
        logout();
        navigate('/login');
      }, 1000); // ✅ Ensure smooth logout transition
    } catch (error) {
      toast.error(error.response?.data?.message || 'Error updating password ❌');
      setLoading(false);
    }
  };

  return (
    <div className="container mt-5">
      <div className="cont">
      <h2 className="text-center">My Profile</h2>

      {/* ✅ Show spinner while processing */}
      {loading && <div className="text-center"><div className="spinner-border text-primary" role="status"></div></div>}

      <form className="row g-3 profile-form" onSubmit={handleSubmit}>
        <div className="col-md-6 offset-md-3">
          <label className="form-label">Username</label>
          <input type="text" className="form-control" name="username" value={formData.username} disabled />
        </div>

        <div className="col-md-6 offset-md-3">
          <label className="form-label">New Password</label>
          <input
            type="password"
            className="form-control"
            name="newPassword"
            placeholder="Enter new password"
            value={formData.newPassword}
            onChange={handleChange}
            required
          />
        </div>

        <div className="col-md-2 offset-md-3 text-center">
          <button className="btn btn-primary w-100" type="submit" disabled={loading}>
            {loading ? 'Updating...' : 'Update Password'}
          </button>
        </div>
      </form>
      </div>
    </div>
  );
};

export default Profile;
