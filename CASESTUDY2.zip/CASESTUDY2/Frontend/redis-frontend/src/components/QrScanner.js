import React, { useState } from 'react';
import { Html5QrcodeScanner } from 'html5-qrcode';
import './QrScanner.css'; // Optional styling

export default function QrScanner() {
  const [scanResult, setScanResult] = useState(null);

  React.useEffect(() => {
    const scanner = new Html5QrcodeScanner('qr-reader', {
      qrbox: {
        width: 250,
        height: 250,
      },
      fps: 5,
    });

    scanner.render(success, error);

    function success(result) {
      scanner.clear();
      setScanResult(result);
    }

    function error(err) {
      console.warn(err);
    }

    return () => scanner.clear(); // Cleanup on unmount
  }, []);

  return (
    <div className="qr-scanner" style={{ minHeight: '500px' }}>
  <h2>Scan QR Code</h2>
  <div id="qr-reader" style={{ width: '100%' }}></div>
  {scanResult && (
    <div className="scan-result">
      <p>Scanned Data: <strong>{scanResult}</strong></p>
    </div>
  )}
</div>
  );
}