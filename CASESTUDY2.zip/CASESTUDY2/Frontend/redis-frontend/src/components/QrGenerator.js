import React, { useState, useEffect } from 'react';
import QRCode from 'react-qr-code';
import axios from 'axios';
import './QrGenerator.css';

export default function StudentQrGenerator() {
  const [students, setStudents] = useState([]);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [qrValue, setQrValue] = useState('');
  const [loading, setLoading] = useState(false);

  // Fetch students from your backend
  useEffect(() => {
    const fetchStudents = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:5000/students', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setStudents(response.data);
      } catch (error) {
        console.error('Error fetching students:', error);
      }
    };
    fetchStudents();
  }, []);

  const generateStudentQr = () => {
    if (!selectedStudent) return;
    
    setLoading(true);
    
    // Create a student data object
    const studentData = {
      id: selectedStudent.id,
      name: `${selectedStudent.firstName} ${selectedStudent.lastName}`,
      address: selectedStudent.presentAddress,
      contact: selectedStudent.cNumber
      // Add other fields you want in the QR
    };

    // Convert to JSON string
    const jsonString = JSON.stringify(studentData);
    setQrValue(jsonString);
    setLoading(false);
  };

  return (
    <div className="qr-generator">
      <h2>Generate Student QR Code</h2>
      
      <div className="student-selector">
        <label>Select Student:</label>
        <select 
          onChange={(e) => setSelectedStudent(students.find(s => s.id === e.target.value))}
          disabled={loading}
        >
          <option value="">Select a student</option>
          {students.map(student => (
            <option key={student.id} value={student.id}>
              {student.firstName} {student.lastName} (ID: {student.id})
            </option>
          ))}
        </select>
      </div>

      <button 
        onClick={generateStudentQr} 
        disabled={!selectedStudent || loading}
      >
        {loading ? 'Generating...' : 'Generate QR Code'}
      </button>

      {qrValue && (
        <div className="qr-code-container">
          <div className="qr-code">
            <QRCode 
              value={qrValue} 
              size={256}
              level="H" // Higher error correction
            />
          </div>
          <div className="student-info">
            {selectedStudent && (
              <>
                <h3>{selectedStudent.firstName}{selectedStudent.middleName} {selectedStudent.lastName}</h3>
                <p>ID: {selectedStudent.id}</p>
                <p>Present Address: {selectedStudent.presentAddress}</p>
                <p>Provincial Address: {selectedStudent.provincialAddress}</p>
                <p>Years of Residency: {selectedStudent.lengthStay}</p>
                <p>Sex: {selectedStudent.sex}</p>
                <p>Civil Status: {selectedStudent.cStatus}</p>
                <p>Date of Birth: {selectedStudent.dob}</p>
                <p>Age: {selectedStudent.age}</p>
                <p>Place of Birth: {selectedStudent.pob}</p>
                <p>Highest Educational Attainment: {selectedStudent.hea}</p>
                <p>Religion: {selectedStudent.religion}</p>
                <p>Contact: {selectedStudent.cNumber}</p>
                <p>Email Address: {selectedStudent.email}</p>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}