const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const { authenticateUser, authorizeRole } = require('../middlewares/auth');
const User = require('../models/User');
const ActivityLog = require('../models/ActivityLog');
require('dotenv').config();

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret';

// 📝 Register User (Admin or Non-Admin)
router.post('/register', [
  body('username').isString().notEmpty(),
  body('password').isLength({ min: 6 }),
  body('role').isIn(['admin', 'user'])
], async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }

  const { username, password, role } = req.body;

  try {
    // Check if user already exists
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: 'Username already exists' });
    }

    // Hash password and create user
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({
      username,
      password: hashedPassword,
      role
    });

    await user.save();
    await logActivity('User Registered', username, 'System');
    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    console.error('Registration Error:', error);
    res.status(500).json({ message: 'Error registering user' });
  }
});

// 🔑 Login User
router.post('/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await User.findOne({ username });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ message: 'Invalid credentials' });

    const token = jwt.sign(
      { _id: user._id, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '1h' }
    );

    // Add token to user's tokens array
    user.tokens = user.tokens.concat({ token });
    await user.save();

    res.json({ token, role: user.role });
  } catch (error) {
    res.status(500).json({ message: 'Login error' });
  }
});

// 🔹 Fetch all users (Only Admins)
router.get('/users', authenticateUser, authorizeRole('admin'), async (req, res) => {
  try {
    const users = await User.find({}, 'username role');
    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching users' });
  }
});

// 🔹 Update a user's role (Only Admins)
router.put('/users/:username', authenticateUser, authorizeRole('admin'), async (req, res) => {
  const { username } = req.params;
  const { role } = req.body;
  const performedBy = req.user.username;

  if (!['admin', 'user'].includes(role)) {
    return res.status(400).json({ message: 'Invalid role' });
  }

  try {
    const user = await User.findOneAndUpdate(
      { username },
      { role },
      { new: true }
    );

    if (!user) return res.status(404).json({ message: 'User not found' });

    await logActivity('Role Updated', username, performedBy);
    res.json({ message: 'User role updated' });
  } catch (error) {
    res.status(500).json({ message: 'Error updating role' });
  }
});

// 🔹 Delete a user (Only Admins)
router.delete('/users/:username', authenticateUser, authorizeRole('admin'), async (req, res) => {
  const { username } = req.params;
  const performedBy = req.user.username;

  try {
    const user = await User.findOneAndDelete({ username });
    if (!user) return res.status(404).json({ message: 'User not found' });

    await logActivity('User Deleted', username, performedBy);
    res.json({ message: 'User deleted' });
  } catch (error) {
    res.status(500).json({ message: 'Error deleting user' });
  }
});

// 🔹 Update user info (including password hashing)
router.put('/profile', authenticateUser, async (req, res) => {
  const { newPassword } = req.body;
  const userId = req.user._id;

  try {
    const user = await User.findById(userId);
    if (!user) return res.status(404).json({ message: 'User not found' });

    if (newPassword) {
      user.password = await bcrypt.hash(newPassword, 10);
      await user.save();
    }

    res.status(200).json({ 
      message: 'Password updated successfully. Please log in again.',
      forceLogout: true 
    });
  } catch (error) {
    res.status(500).json({ message: 'Error updating profile' });
  }
});

// 🔹 Get Activity Logs (Admins Only)
router.get('/logs', authenticateUser, authorizeRole('admin'), async (req, res) => {
  try {
    const logs = await ActivityLog.find().sort({ timestamp: -1 });
    res.json(logs);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching logs' });
  }
});

// Helper function to log activities
const logActivity = async (action, username, performedBy) => {
  try {
    const log = new ActivityLog({
      action,
      username,
      performedBy,
      timestamp: new Date()
    });
    await log.save();
  } catch (error) {
    console.error('Error logging activity:', error);
  }
};

module.exports = router;