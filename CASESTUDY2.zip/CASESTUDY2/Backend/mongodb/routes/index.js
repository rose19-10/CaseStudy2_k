const express = require('express');
const authRoutes = require('./auth');
const studentRoutes = require('./students');
const qrRoutes = require('./qr');

const router = express.Router();

router.use('/auth', authRoutes);
router.use('/students', studentRoutes);
router.use('/qr', qrRoutes);

module.exports = router;