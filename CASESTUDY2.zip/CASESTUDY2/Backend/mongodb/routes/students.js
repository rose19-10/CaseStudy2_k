const express = require('express');
const { authenticateUser, authorizeRole } = require('../middlewares/auth');
const Student = require('../models/Student');

const router = express.Router();

// 📌 Create Student (Only Admins)
router.post('/', authenticateUser, authorizeRole('admin'), async (req, res) => {
  const requiredFields = [
    'id', 'firstName', 'middleName', 'lastName', 'presentAddress', 
    'provincialAddress', 'lengthStay', 'sex', 'cStatus', 'dob', 
    'age', 'pob', 'hea', 'religion', 'cNumber', 'email'
  ];

  for (const field of requiredFields) {
    if (!req.body[field]) {
      return res.status(400).json({ message: `${field} is required` });
    }
  }

  try {
    // Check if student already exists
    const existingStudent = await Student.findOne({ id: req.body.id });
    if (existingStudent) {
      return res.status(400).json({ message: 'Student ID already exists' });
    }

    const student = new Student(req.body);
    await student.save();

    res.status(201).json({ 
      message: 'Student added successfully', 
      student 
    });
  } catch (error) {
    console.error('Error adding student:', error);
    res.status(500).json({ message: 'Error adding student' });
  }
});

// 📌 Get All Students (Accessible to Admin & Users)
router.get('/', authenticateUser, async (req, res) => {
  try {
    const students = await Student.find();
    res.json(students);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch students' });
  }
});

// 📌 Get Single Student
router.get('/:id', authenticateUser, async (req, res) => {
  try {
    const student = await Student.findOne({ id: req.params.id });
    if (!student) {
      return res.status(404).json({ message: 'Student not found' });
    }
    res.json(student);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch student' });
  }
});

// 📌 Update Student (Only Admins)
router.put('/:id', authenticateUser, authorizeRole('admin'), async (req, res) => {
  try {
    const student = await Student.findOneAndUpdate(
      { id: req.params.id },
      req.body,
      { new: true, runValidators: true }
    );

    if (!student) {
      return res.status(404).json({ message: 'Student not found' });
    }

    res.json({ 
      message: 'Student updated successfully',
      student
    });
  } catch (error) {
    res.status(500).json({ message: 'Failed to update student' });
  }
});

// 📌 Delete Student (Only Admins)
router.delete('/:id', authenticateUser, authorizeRole('admin'), async (req, res) => {
  try {
    const student = await Student.findOneAndDelete({ id: req.params.id });
    if (!student) {
      return res.status(404).json({ message: 'Student not found' });
    }
    res.json({ message: 'Student deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Failed to delete student' });
  }
});

module.exports = router;