const express = require('express');
const router = express.Router();
const QRCode = require('qrcode');
const Jimp = require('jimp');
const QRData = require('../models/QRData');

// Generate QR Code
router.get('/generate', async (req, res) => {
  try {
    const data = req.query.data || 'default-data';
    const qrImage = await QRCode.toDataURL(data);
    res.json({ qrCode: qrImage });
  } catch (err) {
    res.status(500).json({ error: 'Failed to generate QR code' });
  }
});

// Store QR data in MongoDB
router.post('/store', async (req, res) => {
  try {
    const { qrId, data } = req.body;
    const qrData = new QRData({
      qrId,
      data
    });
    await qrData.save();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

// Retrieve QR data from MongoDB
router.get('/retrieve/:qrId', async (req, res) => {
  try {
    const { qrId } = req.params;
    const qrData = await QRData.findOne({ qrId });
    if (!qrData) {
      return res.status(404).json({ error: 'QR data not found' });
    }
    res.json({ data: qrData.data });
  } catch (err) {
    res.status(500).json({ error: 'Database error' });
  }
});

module.exports = router;