const mongoose = require('mongoose');

const qrDataSchema = new mongoose.Schema({
  qrId: { type: String, required: true, unique: true },
  data: { type: String, required: true }
}, {
  timestamps: true
});

module.exports = mongoose.model('QRData', qrDataSchema);