const jwt = require('jsonwebtoken');
const User = require('../models/User'); // Import your User model
require('dotenv').config();

const JWT_SECRET = process.env.JWT_SECRET || 'your_jwt_secret';

// 🛡 Middleware for Authentication
const authenticateUser = async (req, res, next) => {
  try {
    // 1. Get token from header
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ message: 'Authentication required' });
    }

    // 2. Verify token
    const decoded = jwt.verify(token, JWT_SECRET);
    
    // 3. Find user in MongoDB (with token still active)
    const user = await User.findOne({
      _id: decoded._id,
      'tokens.token': token // Checking if token is still valid
    });

    if (!user) {
      throw new Error('User not found or token invalid');
    }

    // 4. Attach user and token to request
    req.user = user;
    req.token = token;
    
    next();
  } catch (error) {
    console.error('Authentication error:', error.message);
    res.status(401).json({ message: 'Please authenticate' });
  }
};

// 🎭 Middleware for Role Authorization
const authorizeRole = (roles) => {
  return (req, res, next) => {
    try {
      // Allow roles to be a single string or array of roles
      if (!Array.isArray(roles)) {
        roles = [roles];
      }

      if (!roles.includes(req.user.role)) {
        return res.status(403).json({ 
          message: `Access denied. Required role: ${roles.join(' or ')}`
        });
      }

      next();
    } catch (error) {
      console.error('Authorization error:', error);
      res.status(500).json({ message: 'Authorization check failed' });
    }
  };
};

module.exports = { 
  authenticateUser, 
  authorizeRole
};